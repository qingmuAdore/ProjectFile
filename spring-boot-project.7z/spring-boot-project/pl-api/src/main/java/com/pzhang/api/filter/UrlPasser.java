package com.pzhang.api.filter;

import org.springframework.util.AntPathMatcher;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/1/9
 */
public interface UrlPasser {
    AntPathMatcher antPathMatcher = new AntPathMatcher();

    List<String> getUrls();

    default boolean check(HttpServletRequest request) {
        List<String> urls = getUrls();
        String requestURI = request.getRequestURI();
        for (String url : urls) {
            if (antPathMatcher.match(url, requestURI)) {
                return true;
            }
        }
        return false;
    }
}
package com.pzhang.api.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import org.springframework.http.*;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2021/1/31
 */
public class Utils {
    /**
     * 向目的URL发送post请求
     *
     * @param url 目的url
     * @return ResultVO
     */
    public static <T> T sendPostRequest(String url, Object body, Class<T> cls) {
        RestTemplate client = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        HttpMethod method = HttpMethod.POST;
        // 以表单的方式提交
        headers.setContentType(MediaType.APPLICATION_JSON);
        //将请求头部和参数合成一个请求
        HttpEntity requestEntity = new HttpEntity<Object>(body, headers);
        //执行HTTP请求，将返回的结构使用ResultVO类格式化
        ResponseEntity<T> response = client.exchange(url, method, requestEntity, cls);

        return response.getBody();
    }

    private static ObjectMapper objectMapper;

    static {
        objectMapper = new ObjectMapper();
        //反序列化, 未知属性报错
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        //序列化枚举类型, 使用toString()作为序列化值
        objectMapper.configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true);
    }


    public static String toJSONString(Object obj) {
        try {
            return objectMapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return "";
        }
    }

    public static <T> T toObject(String json, Class<T> clz) {
        try {
            T obj = objectMapper.readValue(json, clz);
            return obj;
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
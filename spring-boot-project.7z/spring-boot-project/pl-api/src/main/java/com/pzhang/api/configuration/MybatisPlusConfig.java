package com.pzhang.api.configuration;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Configuration;

/**
 * Mybatis Plus Config
 */
@Configuration
@MapperScan("com.pzhang.model.mapper")
public class MybatisPlusConfig {


}

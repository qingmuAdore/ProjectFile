package com.pzhang.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2019/3/29
 */
@SpringBootApplication(scanBasePackages = {"com.pzhang.api", "com.pzhang.common", "com.pzhang.model"})
@ServletComponentScan  //注册过滤器注解
public class PlApplication {
    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(PlApplication.class);
        application.run(args);
    }
}
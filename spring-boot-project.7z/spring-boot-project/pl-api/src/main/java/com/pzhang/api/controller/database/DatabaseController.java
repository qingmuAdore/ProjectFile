package com.pzhang.api.controller.database;

import com.pzhang.common.web.response.RequestResult;
import com.pzhang.common.web.response.ResponseUtil;
import com.pzhang.model.entity.User;
import com.pzhang.model.service.IUserService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/21
 */
@RestController
@RequestMapping("database")
public class DatabaseController {
    @Resource
    IUserService userService;

    @GetMapping("/user")
    public RequestResult user() {
        List<User> user = userService.list();
        return ResponseUtil.success(user);
    }

}
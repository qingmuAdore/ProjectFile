package com.pzhang.api.controller.common;

import com.pzhang.api.constant.ResultCode;
import com.pzhang.common.web.RequestException;
import com.pzhang.common.web.response.RequestResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


/**
 * @author pzhang
 * @version v1.0.0
 * @date 2019/3/29
 */
@RestController
@RequestMapping("common/exception")
public class RequestExceptionController {
    @RequestMapping(method = RequestMethod.GET, value = "/error")
    public RequestResult triggerException() throws Exception {
        throw new Exception("trigger exception");
    }

    @RequestMapping(method = RequestMethod.GET, value = "/request_error")
    public RequestResult riggerAjaxException() {
        throw new RequestException(ResultCode.CODE_500);
    }

}
package com.pzhang.api.filter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/1/9
 */
public class AuthFilter implements Filter, UrlPasser {
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthFilter.class);
    List<String> excludeUrls = new ArrayList<>();

    public AuthFilter addExcludeUrls(String... urls) {
        Collections.addAll(this.excludeUrls, urls);
        return this;
    }

    @Override
    public List<String> getUrls() {
        return excludeUrls;
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest httpServletRequest = (HttpServletRequest) request;
        String url = httpServletRequest.getRequestURI();

        LOGGER.info("AuthFilter url: " + url);
        if (!check(httpServletRequest)) {
            System.out.println("  need check login:" + url);
        }
        chain.doFilter(request, response);
    }

    @Override
    public void destroy() {

    }
}
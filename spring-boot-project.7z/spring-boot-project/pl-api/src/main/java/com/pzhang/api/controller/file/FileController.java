package com.pzhang.api.controller.file;

import com.pzhang.api.utils.Utils;
import lombok.Data;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.*;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2021/1/31
 */
@RestController
@RequestMapping("/file")
public class FileController {
    @PostMapping(path = "/face/search")
    public ResultVo faceSearch(@RequestBody Object info) {
        ResultVo vo = new ResultVo();
        vo.setParamString(Utils.toJSONString(info));
        vo.setDateTime(new Date().getTime() + "");

        return vo;
    }


    @PostMapping(path = "/face/search/tx")
    public Object faceSearchTx(@RequestBody Object info) {
        String url = "http://localhost:8080/ajax/file/face/search";
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        MediaType type = MediaType.parseMediaType("application/json; charset=UTF-8");
        headers.setContentType(type);
        headers.add("Accept", MediaType.APPLICATION_JSON.toString());


        HttpEntity<String> formEntity = new HttpEntity<String>(Utils.toJSONString(info), headers);

        ResultVo result = restTemplate.postForObject(url, formEntity, ResultVo.class);
        return result;
    }

    @Data
    private static class ResultVo {
        private String paramString;
        private String dateTime;
    }


    @PostMapping(path = "/upload/{type}")
    public ResultVo uploadFile(@PathVariable Integer type, @RequestParam("file") MultipartFile file) {
        ResultVo vo = new ResultVo();
        vo.setParamString("type:" + type + "   fileName:" + file.getOriginalFilename());
        vo.setDateTime(new Date().getTime() + "");

        return vo;
    }


    @PostMapping(path = "/upload/{type}/tx")
    public ResultVo uploadFileTx(@PathVariable Integer type, @RequestParam("file") MultipartFile multipartFile) throws IOException {
        String url = "http://localhost:8080/ajax/file/upload/" + type;
        RestTemplate restTemplate = new RestTemplate();

        LinkedMultiValueMap<String, Object> map = new LinkedMultiValueMap<String, Object>();
        String tempFilePath;
        FileOutputStream fo;

        // set the multipart file as a parameter
        try {
            tempFilePath = "tmp/" + (new Date().getTime()) + "_" + multipartFile.getOriginalFilename();
            File file = new File(tempFilePath);
            if (!file.getParentFile().exists()) {
                file.getParentFile().mkdirs();
            }
            fo = new FileOutputStream(tempFilePath);

            fo.write(multipartFile.getBytes());
            fo.close();
        } catch (IOException e) {
            String message = "An Error occurred loading the file -- " + e.getMessage();
            throw e;
        }

        map.add("file", new FileSystemResource(tempFilePath));

        // Set http Headers
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.MULTIPART_FORM_DATA);

        HttpEntity<LinkedMultiValueMap<String, Object>> requestEntity = new HttpEntity<LinkedMultiValueMap<String, Object>>(
                map, headers);

//        ResponseEntity<ResultVo> responseEntity = restTemplate.exchange(url, HttpMethod.POST, requestEntity, ResultVo.class);
//        return responseEntity.getBody();

        return restTemplate.postForObject(url, requestEntity, ResultVo.class);
    }

    private HttpHeaders getHeaders(MediaType mediaType) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(mediaType);
        return headers;
    }

}
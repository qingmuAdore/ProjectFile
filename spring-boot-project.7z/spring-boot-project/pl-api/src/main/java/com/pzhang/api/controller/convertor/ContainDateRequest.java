package com.pzhang.api.controller.convertor;

import lombok.Data;

import java.util.Date;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/20
 */
@Data
public class ContainDateRequest {
    private Date date;
}


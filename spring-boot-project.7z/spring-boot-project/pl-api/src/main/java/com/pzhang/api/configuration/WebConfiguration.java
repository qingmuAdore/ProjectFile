package com.pzhang.api.configuration;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.pzhang.api.utils.http.DateJacksonConverter;
import com.pzhang.api.utils.http.StringToDateConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.Date;
import java.util.List;

@Configuration
public class WebConfiguration {
    @Autowired
    private DateJacksonConverter dateJacksonConverter;

    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOriginPatterns("*")  //当前版本(2.6.3) allowedOrigin --> allowedOriginPatterns
                        .allowCredentials(true)
                        .allowedMethods("GET", "POST", "DELETE", "PUT", "PATCH")
                        .maxAge(3600);
            }


            @Override
            public void addFormatters(FormatterRegistry registry) {
                registry.addConverter(new StringToDateConverter());
            }


            @Override
            public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
                JavaTimeModule module = new JavaTimeModule();

                //Jackson处理日期类型
                module.addSerializer(Date.class, dateJacksonConverter.getSerializer());
                module.addDeserializer(Date.class, dateJacksonConverter.getDeserializer());

                ObjectMapper objectMapper = new ObjectMapper();
                objectMapper.registerModule(module);

                //反序列化, 未知属性报错
                objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);

                //序列化枚举类型, 使用toString()作为序列化值
                objectMapper.configure(SerializationFeature.WRITE_ENUMS_USING_TO_STRING, true);

                converters.parallelStream()
                        //过滤出MappingJackson2HttpMessageConverter
                        .filter(httpMessageConverter -> httpMessageConverter instanceof MappingJackson2HttpMessageConverter)
                        //将所有MappingJackson2HttpMessageConverter中的objectMapper替换成自定义的策略
                        .forEach(httpMessageConverter -> ((MappingJackson2HttpMessageConverter) httpMessageConverter).setObjectMapper(objectMapper));
            }
        };
    }
}

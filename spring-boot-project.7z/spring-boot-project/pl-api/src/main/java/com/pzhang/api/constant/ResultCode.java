package com.pzhang.api.constant;

import com.pzhang.common.web.response.IResultCode;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/20
 */
public enum ResultCode implements IResultCode {
    SUCCESS(IResultCode.CODE_SUCCESS, "成功"),
    FAIL(IResultCode.CODE_FAILED, "失败"),
    NOT_EXIST(2, "不存在"),
    CODE_500(502, "服务器异常"),
    ACCESS_TOKEN_ERROR(405, "令牌错误"),
    CODE_403(403, "无访问权限"),
    INTERNAL_ACCESS_ERROR(406, "该接口只能给内部程序访问"),
    REQUEST_ID_ERROR(407, "请求ID错误"),
    REQUEST_ID_REPEART(408, "请求ID重复"),
    REQUEST_TOO_FREQUENT(409, "请求太频繁"),
    IP_IN_BLACKLIST(410, "IP在黑名单"),
    REQUEST_PARAM_ERROR(411, "参数错误");


    ResultCode(int code, String errorMsg) {
        this.code = code;
        this.message = errorMsg;
    }

    public final int code;
    public final String message;

    @Override
    public int getCode() {
        return code;
    }

    @Override
    public String getMessage() {
        return message;
    }
}
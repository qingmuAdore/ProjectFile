package com.pzhang.api.utils.http;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.pzhang.common.utils.DateUtils;
import lombok.Data;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.jackson.JsonComponent;
import org.springframework.context.annotation.Scope;

import java.io.IOException;
import java.util.Date;

/**
 * jackson 日期转转化器
 *
 * @author pzhang
 * @version v1.0.0
 * @date 2019/11/28
 */
@JsonComponent
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
@Data
public class DateJacksonConverter {
    private DateJacksonSerializer serializer = new DateJacksonSerializer();

    private DateJacksonDeserializer deserializer = new DateJacksonDeserializer();

    /**
     * 序列化将日期转化
     * <p>
     * 考虑不同位置的时间格式有差异,返回时间戳 (long类型可能失真,采用字符串)
     */
    public static class DateJacksonSerializer extends JsonSerializer<Date> {

        @Override
        public void serialize(Date value, JsonGenerator gen, SerializerProvider serializers) throws IOException {

            /**
             * 时间戳js,会失真返回字符串
             */
            gen.writeString((value == null) ? "" : value.getTime() + "");
        }

        @Override
        public Class<Date> handledType() {
            return Date.class;
        }
    }


    /**
     * 自定义Jackson反序列化日期类型时应用的类型转换器,一般用于@RequestBody接受参数时使用
     */
    public static class DateJacksonDeserializer extends JsonDeserializer<Date> {

        @Override
        public Date deserialize(JsonParser p, DeserializationContext ctx) throws IOException {
            String originDate = p.getText();
            return DateUtils.toDate(originDate);
        }

        @Override
        public Class<?> handledType() {
            return Date.class;
        }
    }


}
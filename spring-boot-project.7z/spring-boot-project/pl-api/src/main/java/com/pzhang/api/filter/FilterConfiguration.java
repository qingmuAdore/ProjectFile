package com.pzhang.api.filter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/1/9
 */
//@Configuration
public class FilterConfiguration {
    @Bean
    public FilterRegistrationBean authFilterBean() {
        AuthFilter authFilter = new AuthFilter();
        authFilter.addExcludeUrls("/auth/*", "/home");
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(authFilter);
        filterRegistrationBean.addUrlPatterns("/*");
        filterRegistrationBean.setOrder(1);//order的数值越小 则优先级越高
        return filterRegistrationBean;
    }
}
package com.pzhang.api.controller.common;

import com.pzhang.common.web.response.RequestResult;
import com.pzhang.common.web.response.ResponseUtil;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/1/9
 */
@RestController
@RequestMapping("common/auth")
public class AuthController {
    @GetMapping("/login")
    public RequestResult login() {
        return ResponseUtil.success();
    }

    @GetMapping("/logout")
    public RequestResult logout() {
        return ResponseUtil.success();
    }

    @GetMapping("/register")
    public RequestResult register() {
        return ResponseUtil.success();
    }
}
package com.pzhang.api.utils.http;

import com.pzhang.common.utils.DateUtils;
import org.springframework.core.convert.converter.Converter;

import java.util.Date;

/**
 * 字符串转日期
 * <p>
 * 使用: 当HTTP请求处理采用query参数(一般GET 请求)转化请求实体时, 处理Date属性转化
 *
 * @author pzhang
 * @version v1.0.0
 * @date 2019/11/29
 */
public class StringToDateConverter implements Converter<String, Date> {
    @Override
    public Date convert(String source) {
        return DateUtils.toDate(source);
    }
}
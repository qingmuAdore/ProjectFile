package com.pzhang.api.controller.convertor;

import com.pzhang.common.web.response.RequestResult;
import com.pzhang.common.web.response.ResponseUtil;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/20
 */
@RestController
@RequestMapping("/convertor/date")
public class DateConvertorController {

    /**
     * 当GET 请求时, 若出现Date类型:
     * <p>
     * 其将会根据: date{long, 其他日期格式, 转换为Date类型}
     * 具体实现: StringToDateConverter.convert (String source)
     * <p>
     * eg:
     * localhost:8080/convertor/date/toDate?date=1644666323000
     * localhost:8080/convertor/date/toDate?date=2022-02-12 19:45:23
     * <p>
     * 配置见{@link com.pzhang.api.configuration.WebConfiguration}
     * <code>
     * public void addFormatters(FormatterRegistry registry) {
     * registry.addConverter(new StringToDateConverter());
     * }
     * </code>
     *
     * @param date
     * @return
     */
    @GetMapping("/getDate")
    public RequestResult getDate(Date date) {
        return ResponseUtil.success(date);
    }

    /**
     * toDate
     * <p>
     * 当 @RequestBody实体中有Date字段 eg: {@link ContainDateRequest#getDate()}
     * 将date的参数反序列化为Date
     * 实现逻辑:
     * module.addDeserializer(Date.class, dateJacksonConverter.getDeserializer());
     * <p>
     * <p>
     * 当返回json对象,有Date属性时, eg:{@link ContainDateResponse#getCurrDate()}
     * 会将date属性的值, 转换为时间戳字符串
     * 实现逻辑:
     * module.addSerializer(Date.class, dateJacksonConverter.getSerializer());
     */
    @PostMapping("/toDate")
    public RequestResult toDate(@RequestBody ContainDateRequest request) {
        Date date = request.getDate();

        ContainDateResponse response = new ContainDateResponse();
        response.setDate(date);
        response.setCurrDate(new Date());
        return ResponseUtil.success(response);
    }
}
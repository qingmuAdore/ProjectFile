package plugins;

import com.baomidou.mybatisplus.generator.FastAutoGenerator;
import com.baomidou.mybatisplus.generator.config.DataSourceConfig;
import org.apache.ibatis.jdbc.ScriptRunner;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/20
 */
public class MyBatisCodeGenerator {
    /**
     * 执行初始化数据库脚本
     */
    public static void before() throws SQLException {
        Connection conn = DATA_SOURCE_CONFIG.build().getConn();
        InputStream inputStream = MyBatisCodeGenerator.class.getResourceAsStream("/sql/init.sql");
        ScriptRunner scriptRunner = new ScriptRunner(conn);
        scriptRunner.setAutoCommit(true);
        scriptRunner.runScript(new InputStreamReader(inputStream));
        conn.close();
    }

    /**
     * 数据源配置
     */
    private static final DataSourceConfig.Builder DATA_SOURCE_CONFIG = new DataSourceConfig
            .Builder("jdbc:mysql://47.106.87.114:33060/pl_test", "pauly", "8895andy");


    private static String getProjectSourcePath() {
        String projectPath = System.getProperty("user.dir");
        projectPath += "/pl-model/src/main/java";
        return projectPath;
    }

    private static String getProjectResource() {
        String projectPath = System.getProperty("user.dir");
        projectPath += "/pl-model/src/main/resource/mapper";
        return projectPath;
    }


    /**
     * 执行 run
     */
    public static void main(String[] args) throws SQLException {
        FastAutoGenerator.create(DATA_SOURCE_CONFIG)
                // 全局配置
                .globalConfig((scanner, builder)
                        -> builder
                        .outputDir(getProjectSourcePath())
                        .disableOpenDir()
                        .fileOverride()
                        .author("pauly")
                )
                // 包配置
//                .packageConfig((scanner, builder) -> builder.parent(scanner.apply("请输入包名")))
                .packageConfig((scanner, builder) -> builder.parent("com.pzhang.model"))
                // 策略配置
                .strategyConfig((scanner, builder) -> builder.addInclude(scanner.apply("请输入表名，多个表名用,隔开")))
                .templateConfig((scanner, builder) -> builder.controller(null))
                /*
                    模板引擎配置，默认 Velocity 可选模板引擎 Beetl 或 Freemarker
                   .templateEngine(new BeetlTemplateEngine())
                   .templateEngine(new FreemarkerTemplateEngine())
                 */
                .execute();
    }
}

package com.pzhang.model.mapper;

import com.pzhang.model.entity.User;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author pauly
 * @since 2022-02-20
 */
public interface UserMapper extends BaseMapper<User> {

}

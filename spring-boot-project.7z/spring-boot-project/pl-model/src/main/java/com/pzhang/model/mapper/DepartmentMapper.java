package com.pzhang.model.mapper;

import com.pzhang.model.entity.Department;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author pauly
 * @since 2022-02-21
 */
public interface DepartmentMapper extends BaseMapper<Department> {

}

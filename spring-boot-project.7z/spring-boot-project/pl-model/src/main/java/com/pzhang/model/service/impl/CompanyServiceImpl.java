package com.pzhang.model.service.impl;

import com.pzhang.model.entity.Company;
import com.pzhang.model.mapper.CompanyMapper;
import com.pzhang.model.service.ICompanyService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author pauly
 * @since 2022-02-20
 */
@Service
public class CompanyServiceImpl extends ServiceImpl<CompanyMapper, Company> implements ICompanyService {

}

package com.pzhang.model.mapper;

import com.pzhang.model.entity.Company;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author pauly
 * @since 2022-02-20
 */
public interface CompanyMapper extends BaseMapper<Company> {

}

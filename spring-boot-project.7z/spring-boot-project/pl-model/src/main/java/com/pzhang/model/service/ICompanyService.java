package com.pzhang.model.service;

import com.pzhang.model.entity.Company;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author pauly
 * @since 2022-02-20
 */
public interface ICompanyService extends IService<Company> {

}

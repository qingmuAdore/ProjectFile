package com.pzhang.model.service;

import com.pzhang.model.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author pauly
 * @since 2022-02-20
 */
public interface IUserService extends IService<User> {

}

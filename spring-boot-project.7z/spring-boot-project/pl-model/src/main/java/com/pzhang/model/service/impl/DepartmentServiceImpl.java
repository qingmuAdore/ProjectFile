package com.pzhang.model.service.impl;

import com.pzhang.model.entity.Department;
import com.pzhang.model.mapper.DepartmentMapper;
import com.pzhang.model.service.IDepartmentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author pauly
 * @since 2022-02-21
 */
@Service
public class DepartmentServiceImpl extends ServiceImpl<DepartmentMapper, Department> implements IDepartmentService {

}

package com.pzhang.model.service;

import com.pzhang.model.entity.Department;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author pauly
 * @since 2022-02-21
 */
public interface IDepartmentService extends IService<Department> {

}

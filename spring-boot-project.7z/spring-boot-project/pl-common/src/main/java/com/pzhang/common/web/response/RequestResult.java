package com.pzhang.common.web.response;

import lombok.Data;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2019/3/29
 */
@Data
public class RequestResult<T> {
    private int code;
    private String message;
    private T data;

    public RequestResult() {

    }

    public RequestResult(IResultCode resultCode) {
        this.code = resultCode.getCode();
        this.message = resultCode.getMessage();
    }
}
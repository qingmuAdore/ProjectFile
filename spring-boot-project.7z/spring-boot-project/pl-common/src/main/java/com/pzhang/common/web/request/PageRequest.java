package com.pzhang.common.web.request;


import lombok.Data;
import lombok.EqualsAndHashCode;

import java.beans.Transient;
import java.util.List;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2021/1/9
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class PageRequest extends NormalRequest {
    private List<FieldSort> sorts;

    private Integer pageNumber = 1;

    private Integer pageSize = 50;

    @Transient
    public boolean isSearchCount() {
        return pageSize < Integer.MAX_VALUE;
    }
}
package com.pzhang.common.utils.convertor;

import java.util.Map;

/**
 * map转换器
 *
 * @author Lenovo
 * @version v1.0.0
 * @date 2021/11/29
 */
public interface MapConvertor {

    <T> T toObject(Map<String, Object> map, Class<T> clz);

    Map toMap(Object obj);
}
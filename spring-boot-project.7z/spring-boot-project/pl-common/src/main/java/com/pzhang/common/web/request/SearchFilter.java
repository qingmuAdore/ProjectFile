package com.pzhang.common.web.request;

import lombok.Data;
import org.apache.commons.lang3.StringUtils;

import java.beans.Transient;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2021/1/9
 */
@Data
public class SearchFilter {
    public static final String SPLIT_SYMBOL = ",";

    private String paramName;
    private String paramOperator;
    private String value;

    public enum Operator {
        /**
         * 等于
         */
        EQ("EQ"),
        /**
         * 大于
         */
        GT("GT"),
        /**
         * 大于或等于(不小于)
         */
        GE("GE"),
        /**
         * 小于
         */
        LT("LT"),

        /**
         * 小于或等于(不大于)
         */
        LE("LE"),
        /**
         * 属于
         */
        IN("IN"),

        /**
         * 包含
         */
        LIKE("LIKE"),

        /**
         * 不包含
         */
        NOTLIKE("NOTLIKE");

        private static final Map<String, Operator> MAP = new HashMap<>();

        static {
            for (Operator season : values()) {
                MAP.put(season.name, season);
            }
        }

        String name;

        Operator(String name) {
            this.name = name;
        }

        /**
         * 通过名称获取枚举
         *
         * @param name
         * @return
         */
        public static Operator ofName(String name) {
            return MAP.get(name.toUpperCase());
        }

        /**
         * 判断是否合法的操作符
         *
         * @return
         */
        public Boolean validOperator() {
            Operator operator = ofName(name);
            return null != operator;
        }

    }


    @Transient
    public String getTrimValue() {
        if (StringUtils.isNotEmpty(value)) {
            return value.trim();
        }
        return null;
    }

    @Transient
    public List<String> getParamList() {
        List<String> paramList = null;
        if (StringUtils.isNotEmpty(value)) {
            String[] paramStrings = value.trim().split(SearchFilter.SPLIT_SYMBOL);
            if (paramStrings.length > 0) {
                paramList = Arrays.asList(paramStrings);
            }
        }
        return paramList;
    }


}
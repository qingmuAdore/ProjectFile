package com.pzhang.common.web.response;

/**
 * 应答工具类
 *
 * @author pzhang
 * @version v1.0.0
 * @date 2019/3/29
 */
public class ResponseUtil {

    public static RequestResult success() {
        return success("success", null);
    }

    public static RequestResult success(Object obj) {
        return success("success", obj);
    }

    public static RequestResult success(String msg, Object data) {
        return sendResult(IResultCode.CODE_SUCCESS, msg, data);
    }

    public static RequestResult fail() {
        return fail("failed", null);
    }

    public static RequestResult fail(Object obj) {
        return fail("failed", obj);
    }

    public static RequestResult fail(String msg, Object data) {
        return sendResult(IResultCode.CODE_FAILED, msg, data);
    }


    public static RequestResult response(IResultCode resultCode) {
        return response(resultCode, null);
    }

    public static RequestResult response(IResultCode resultCode, Object object) {
        return sendResult(resultCode.getCode(), resultCode.getMessage(), object);
    }

    protected static RequestResult sendResult(int code, String msg, Object data) {
        RequestResult result = new RequestResult();
        result.setCode(code);
        result.setMessage(msg);
        result.setData(data);
        return result;
    }
}
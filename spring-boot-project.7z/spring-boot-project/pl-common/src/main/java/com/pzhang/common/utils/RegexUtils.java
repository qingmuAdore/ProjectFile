package com.pzhang.common.utils;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2019/6/2
 */
public class RegexUtils {

    /***
     * 提取数字字符串
     *
     * @param str
     * @return
     */
    public static String extractNumberString(String str) {
        String numberString = str.replaceAll("[^0-9]", "").trim();
        return numberString;
    }

}
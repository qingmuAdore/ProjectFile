package com.pzhang.common.web.request;

import lombok.Data;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2021/1/9
 */
@Data
public class FieldSort {
    public static final String ASC = "ASC";
    public static final String DESC= "DESC";

    private String column;

    private String order;
}
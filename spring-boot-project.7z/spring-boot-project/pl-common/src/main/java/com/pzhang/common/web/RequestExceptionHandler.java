package com.pzhang.common.web;

import com.pzhang.common.web.response.RequestResult;
import com.pzhang.common.web.response.ResponseUtil;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


/**
 * @author pzhang
 * @version v1.0.0
 * @date 2019/3/29
 */
@RestControllerAdvice
public class RequestExceptionHandler {

    @ExceptionHandler(Exception.class)
    public RequestResult handle(Exception ex) {
        ex.printStackTrace();
        return ResponseUtil.fail(ex.getMessage());
    }

    @ExceptionHandler(RequestException.class)
    public RequestResult handle(RequestException ex) {
        ex.printStackTrace();
        return ResponseUtil.response(ex.getResultCode());
    }
}
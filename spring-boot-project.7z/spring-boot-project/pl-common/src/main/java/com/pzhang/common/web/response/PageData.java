package com.pzhang.common.web.response;

import lombok.Data;

import java.util.List;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/20
 */
@Data
public class PageData<T> {
    /**
     * 结果总数
     */
    private Long total = 0L;

    /**
     * 分页结果
     */
    private List<T> list;
}
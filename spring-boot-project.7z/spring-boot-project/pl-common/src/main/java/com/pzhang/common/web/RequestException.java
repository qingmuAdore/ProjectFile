package com.pzhang.common.web;

import com.pzhang.common.web.response.IResultCode;

/**
 * 请求异常
 *
 * @author pzhang
 * @version v1.0.0
 * @date 2019/3/29
 */
public class RequestException extends RuntimeException {
    private IResultCode resultCode;

    public RequestException(IResultCode resultCode) {
        this.resultCode = resultCode;
    }

    public IResultCode getResultCode() {
        return resultCode;
    }
}
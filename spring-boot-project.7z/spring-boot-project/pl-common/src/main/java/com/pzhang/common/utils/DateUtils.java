package com.pzhang.common.utils;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class DateUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);

    private static String[] PATTERN =
            new String[]{
                    "yyyy-MM-dd", "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm:ss.S",
                    "yyyy.MM.dd", "yyyy.MM.dd HH:mm", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm:ss.S",
                    "yyyy/MM/dd", "yyyy/MM/dd HH:mm", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm:ss.S"};

    /***
     * 时间字符串转日期
     *
     * - 支持时间戳字符串: ms时间戳
     *
     * - 支持日期字符串格式如下:
     * "yyyy-MM-dd", "yyyy-MM-dd HH:mm", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm:ss.S",
     * "yyyy.MM.dd", "yyyy.MM.dd HH:mm", "yyyy.MM.dd HH:mm:ss", "yyyy.MM.dd HH:mm:ss.S",
     * "yyyy/MM/dd", "yyyy/MM/dd HH:mm", "yyyy/MM/dd HH:mm:ss", "yyyy/MM/dd HH:mm:ss.S"
     *
     * @return
     */
    public static Date toDate(String dateString) {
        Date targetDate = null;
        if (StringUtils.isNotEmpty(dateString)) {
            try {
                long longDate = Long.valueOf(dateString.trim());
                targetDate = new Date(longDate);
            } catch (NumberFormatException e) {
                try {
                    targetDate = org.apache.commons.lang3.time.DateUtils.parseDate(dateString, PATTERN);
                } catch (ParseException pe) {
                    LOGGER.warn(String.format(
                            "'%s' can not convert to type 'java.util.Date',just support timestamp(type of long) and following date format(%s)",
                            dateString,
                            StringUtils.join(PATTERN, ",")));
                    return null;
                }
            }
        }
        return targetDate;
    }

    /**
     * 当天时间格式(eg: 2019-04-18)
     *
     * @return
     */
    public static String getDayString(LocalDateTime date) {
        return getDateString(date, "yyyy-MM-dd");
    }

    /**
     * 当月时间格式(eg:2019-04)
     *
     * @return
     */
    public static String getMonthString(LocalDateTime date) {
        return getDateString(date, "yyyy-MM");

    }

    /**
     * 日期转指定格式字符串
     * <p>
     * yyyy -- 年
     * MM   -- 月
     * dd   -- 日
     * HH   -- 时
     * mm   -- 分
     * ss   -- 秒
     * SSS  -- 毫秒
     *
     * @param date   默认当前时间
     * @param format 默认格式 yyyyMMdd
     * @return
     */
    public final static String getDateString(LocalDateTime date, String format) {
        if (date == null) {
            date = LocalDateTime.now();
        }
        if (format == null || "".equals(format)) {
            format = "yyyyMMdd";
        }

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format);
        return dtf.format(date);
    }
}

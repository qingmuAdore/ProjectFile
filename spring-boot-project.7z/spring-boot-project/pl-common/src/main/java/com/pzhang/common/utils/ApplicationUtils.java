package com.pzhang.common.utils;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2018/12/6
 */
public class ApplicationUtils {

    private volatile static ApplicationUtils instance = null;

    private ApplicationContext applicationContext;

    private ApplicationUtils() {
    }

    public static ApplicationUtils getInstance() {
        if (instance == null) {
            synchronized (ApplicationUtils.class) {
                if (instance == null) {
                    instance = new ApplicationUtils();
                }
            }
        }
        return instance;
    }

    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }

    public void setApplicationContext(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    public Object getBean(String beanName) throws BeansException {
        return applicationContext.getBean(beanName);
    }

    public <T> T getBean(Class<T> requiredType) throws BeansException {
        return applicationContext.getBean(requiredType);
    }
}
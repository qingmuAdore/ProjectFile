package com.pzhang.common.web.response;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/2/20
 */
public interface IResultCode {
    int CODE_SUCCESS = 0;
    int CODE_FAILED = 1;

    // 返回码
    int getCode();

    // 返回码说明
    String getMessage();
}
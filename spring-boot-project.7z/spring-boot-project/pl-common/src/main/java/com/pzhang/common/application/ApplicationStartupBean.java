package com.pzhang.common.application;

/**
 * 应用启动之后，启动该接口的实现类
 */
public interface ApplicationStartupBean {
	
	
	void onStart();
	
	/**
	 * 执行顺序,值越大,越先执行
	 * @return
	 */
	int getOrder();

}

package com.pzhang.common.application;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationEvent;

/**
 * 定义应用启动事件
 */
public class ApplicationStartupEvent extends ApplicationEvent {

    /**
     *
     */
    private static final long serialVersionUID = -7772986983352093152L;

    private ApplicationContext applicationContext;

    public ApplicationStartupEvent(ApplicationContext context, Object source) {
        super(source);
        this.applicationContext = context;
    }

    public ApplicationContext getApplicationContext() {
        return applicationContext;
    }


}

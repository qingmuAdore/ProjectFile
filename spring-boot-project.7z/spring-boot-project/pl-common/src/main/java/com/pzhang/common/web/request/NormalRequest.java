package com.pzhang.common.web.request;


import com.pzhang.common.utils.DateUtils;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import java.beans.Transient;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author pzhang
 * @version v1.0.0
 * @date 2021/1/29
 */

@Data
@EqualsAndHashCode(callSuper = false)
public class NormalRequest {
    protected List<SearchFilter> filters;

    /**
     * 通过参数名,读取对应的参数条件
     *
     * @param name
     * @return
     */
    @Transient
    public SearchFilter getFilter(String name, SearchFilter.Operator operator) {
        if (!CollectionUtils.isEmpty(filters)) {
            for (SearchFilter filter : filters) {
                if (name.equals(filter.getParamName())
                        && operator.name.equals(filter.getParamOperator().toUpperCase())) {
                    return filter;
                }
            }
        }
        return null;
    }

    @Transient
    public String getParamValue(String name, SearchFilter.Operator operator) {
        SearchFilter searchFilter = getFilter(name, operator);
        if (searchFilter != null) {
            return searchFilter.getTrimValue();
        }
        return null;
    }


    /**
     * 对于IN操作符
     *
     * @param name
     * @return
     */
    @Transient
    public List<String> getParamList(String name) {
        SearchFilter searchFilter = getFilter(name, SearchFilter.Operator.IN);
        if (searchFilter != null) {
            return searchFilter.getParamList();
        }
        return null;
    }


    /**
     * 对于IN操作符
     *
     * @param name
     * @return
     */
    @Transient
    public List<Integer> getParamIntegerList(String name) {
        SearchFilter searchFilter = getFilter(name, SearchFilter.Operator.IN);
        if (searchFilter != null) {
            List<Integer> paramList = null;
            String value = searchFilter.getValue();
            if (StringUtils.isNotEmpty(value)) {
                String[] paramStrings = value.trim().split(SearchFilter.SPLIT_SYMBOL);
                if (paramStrings.length > 0) {
                    paramList = new ArrayList<>();

                    for (String paramValue : paramStrings) {
                        paramList.add(Integer.valueOf(paramValue));
                    }
                }
            }
            return paramList;
        }
        return null;
    }


    @Transient
    public String getParamValueByEq(String name) {
        return getParamValue(name, SearchFilter.Operator.EQ);
    }

    /**
     * 时间参数值
     *
     * @param name
     * @return
     */
    @Transient
    public Date getDate(String name, SearchFilter.Operator operator) {
        return DateUtils.toDate(getParamValue(name, operator));
    }

    @Transient
    public Integer getInteger(String name, SearchFilter.Operator operator) {
        try {
            return Integer.valueOf(getParamValue(name, operator));
        } catch (Exception e) {
            return null;
        }
    }

}
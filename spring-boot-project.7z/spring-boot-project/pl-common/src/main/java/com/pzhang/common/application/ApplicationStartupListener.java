package com.pzhang.common.application;

import com.pzhang.common.utils.ApplicationUtils;
import org.springframework.context.ApplicationListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 系统中存在两个容器,第一个是spring的基本容器,第二个容器才是存放自定义Bean的容器.
 * 所以在第二个容器完成后，才调用。
 * <p>
 * 说明:
 * <p>
 * 使用场景:
 *
 * @version 1 : @author Wang Shaohong	Mail: 994233303@qq.com
 */
public class ApplicationStartupListener implements ApplicationListener<ApplicationStartupEvent> {
    private static final Logger logger = LoggerFactory.getLogger(ApplicationStartupListener.class);

    @Override
    public synchronized void onApplicationEvent(ApplicationStartupEvent event) {
        ApplicationUtils.getInstance().setApplicationContext(event.getApplicationContext());
        logger.info("\n\n---------- Application Started  --------\n\n");
        doOnApplicationEvent(event);
    }


    protected void doOnApplicationEvent(ApplicationStartupEvent event) {
        Map<String, ApplicationStartupBean> startupBeans = event.getApplicationContext().getBeansOfType(ApplicationStartupBean.class);
        if (startupBeans != null && !startupBeans.isEmpty()) {

            List<ApplicationStartupBean> startupList = new ArrayList<ApplicationStartupBean>();
            for (String key : startupBeans.keySet()) {
                startupList.add(startupBeans.get(key));
            }

            Collections.sort(startupList, (o1, o2) -> o2.getOrder() - o1.getOrder());

            for (ApplicationStartupBean startup : startupList) {
                logger.info("{} is starting", startup.getClass().getName());
                try {
                    startup.onStart();
                } catch (Exception ex) {
                    logger.error(ex.getMessage(), ex);
                }
            }

        }
    }
}

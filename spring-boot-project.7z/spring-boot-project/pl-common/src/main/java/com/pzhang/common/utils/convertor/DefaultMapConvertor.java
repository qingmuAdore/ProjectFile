package com.pzhang.common.utils.convertor;


import org.apache.commons.beanutils.BeanMap;
import org.apache.commons.beanutils.BeanUtils;

import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/**
 * 默认map 转换器
 *
 * @author Lenovo
 * @version v1.0.0
 * @date 2021/11/29
 */
public class DefaultMapConvertor implements MapConvertor {
    @Override
    public <T> T toObject(Map<String, Object> map, Class<T> beanClass) {
        if (map == null) {
            return null;
        }

        Object obj = null;
        try {
            obj = beanClass.newInstance();
            BeanUtils.populate(obj, map);

        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InstantiationException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return (T) obj;
    }

    @Override
    public Map toMap(Object obj) {
        if (obj == null) return null;

        return new BeanMap(obj);

    }

}
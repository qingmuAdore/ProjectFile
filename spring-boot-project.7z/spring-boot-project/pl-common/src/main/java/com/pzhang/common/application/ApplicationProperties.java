package com.pzhang.common.application;

import java.util.Properties;

/**
 * 应用属性
 * <p>
 * 说明:
 * <li>windows默认为开发环境
 * <li>其它为正式环境
 * <li>可以通过{@link #getInstance()}获取实例后，进行自定义设置
 * <p>
 * 使用场景:
 */
public final class ApplicationProperties extends Properties{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2048882091892937262L;

	private static String applicationName;
	
	private final static String KEY_UPGRADING = "upgrading";

	private final static String KEY_DEVELOP = "develop";
	
	private ApplicationProperties() {}
	
	private static ApplicationProperties instance = null;
	
	static {
		instance = new ApplicationProperties();
		
		boolean isWindow = System.getProperties().getProperty("os.name").toUpperCase().indexOf("WINDOWS")>=0;
		
		instance.put(KEY_UPGRADING, false);
		instance.put(KEY_DEVELOP, isWindow);
	}
	
	public static ApplicationProperties getInstance() {
		return instance;
	}
	
	/**
	 * 是否正在升级
	 * @return
	 */
	public static boolean isUpgrading() {
		return (Boolean)instance.get(KEY_UPGRADING);
	}
	
	/**
	 * 是否为开发环境
	 * @return
	 */
	public static boolean isDevelopEnvironment() {
		return (Boolean)instance.get(KEY_DEVELOP);
	}
	
	/**
	 * 设置是否为开发者模式
	 * @param isDevelop
	 */
	public static void setDevelopEnvironment(boolean isDevelop) {
		instance.put(KEY_DEVELOP, isDevelop);
	}
	
	/**
	 * 是否为生产环境
	 * @return
	 */
	public static boolean isProductionEnvironment() {
		return ! isDevelopEnvironment();
	}

	/**
	 * @return the applicationName
	 */
	public static String getApplicationName() {
		return applicationName;
	}

	/**
	 * @param applicationName the applicationName to set
	 */
	public static void setApplicationName(String applicationName) {
		ApplicationProperties.applicationName = applicationName;
	}
	

}

package top.anemone.walaDemo.analyzer;


import java.util.*;

/**
 * @author z30022129
 * @version v1.0.0
 * @date 2022/3/10
 */
public class VariableNumberManager {
    private Map<Integer, Set<Integer>> localVariableMap = new LinkedHashMap<>();

    // 记录已处理的变量序号
    private Integer currVn = 0;

    public VariableNumberManager(List<Integer> parameterVNList) {
        for (Integer parameterVN : parameterVNList) {
            Set<Integer> parameterSet = new TreeSet<>();
            parameterSet.add(parameterVN);
            localVariableMap.put(parameterVN, parameterSet);

            if (parameterVN > currVn) {
                currVn = parameterVN;
            }
        }
    }

    /**
     * 溯源变量的方法参数
     * 确定临时变量是否被参数污染, 以及被污染的方法参数列表
     * <p>
     * 实现原理: 根据wala IR变量规则, 有新的变量产生,其序号将会递增.
     * 意味着新变量只会受它上级变量影响[上级变量: 可通过 getUse() 获取]
     * 既而若知道上级变量溯源的方法参数,则当前变量的溯源参数也可知
     *
     * @param vn           当前变量序号
     * @param parentVnList 上级变量序号列表
     */
    public void traceMethodParameter(Integer vn, List<Integer> parentVnList) {
        /**
         * 避免重复操作以及非法操作
         */
        if (check(vn)) {
            currVn = vn;

            // 记录溯源的方法参数集合
            Set<Integer> parameterSet = new TreeSet<>();
            for (Integer parentVn : parentVnList) {
                if (isValid(vn, parentVn)) {
                    Set<Integer> set = localVariableMap.get(parentVn);
                    if (isNotEmpty(set)) {
                        parameterSet.addAll(set);
                    }
                }
            }

            // 若集合不为空, 记录变量溯源的方法参数
            if (isNotEmpty(parameterSet)) {
                localVariableMap.put(vn, parameterSet);
            }
        }
    }

    public static boolean isNotEmpty(Collection<Integer> collection) {
        return collection != null && !collection.isEmpty();
    }

    /**
     * vn是单调递增
     */
    private boolean check(Integer vn) {
        return vn > currVn;
    }

    /**
     * 当前变量序号(vn)必然比它上级(parentVn)大
     * 受wala本身的约束,可以不做校验
     */
    private boolean isValid(Integer vn, Integer parentVn) {
        return vn > parentVn;
    }

    public Set<Integer> getParameters(Integer key) {
        return localVariableMap.get(key);
    }

    public void print() {
        Set<Map.Entry<Integer, Set<Integer>>> entries = localVariableMap.entrySet();
        for (Map.Entry<Integer, Set<Integer>> entry : entries) {
            Integer key = entry.getKey();
            Set<Integer> value = entry.getValue();
            display(key, value);
        }
    }

    private void display(Integer key, Set<Integer> value) {
        StringBuilder sb = new StringBuilder();
        sb.append("v" + key);
        sb.append(" params:");
        for (Integer p : value) {
            sb.append("v" + p + " ");
        }
        System.out.println(sb);
    }
}
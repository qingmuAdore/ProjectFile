package top.anemone.walaDemo.analyzer;

import com.ibm.wala.classLoader.IClass;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.ipa.callgraph.AnalysisCacheImpl;
import com.ibm.wala.ipa.callgraph.AnalysisOptions;
import com.ibm.wala.ipa.callgraph.AnalysisScope;
import com.ibm.wala.ipa.cha.ClassHierarchy;
import com.ibm.wala.ipa.cha.ClassHierarchyException;
import com.ibm.wala.ipa.cha.ClassHierarchyFactory;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SSAInstruction;
import com.ibm.wala.types.ClassLoaderReference;
import com.ibm.wala.util.config.AnalysisScopeReader;
import com.ibm.wala.util.io.FileProvider;
import top.anemone.walaDemo.broken.ScopeFileCallGraph;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

/**
 * @author z30022129
 * @version v1.0.0
 * @date 2022/3/09
 */
public class DataFlowAnalyzer {
    public static void main(String[] args) {
        AnalysisScope scope = generateAnalysisScope();
        analyse(scope);
    }

    private static AnalysisScope generateAnalysisScope() {
        AnalysisScope scope = null;
        try {
            scope = AnalysisScopeReader.readJavaScope("my_wala_target_javascope.txt", new FileProvider().getFile("Java60RegressionExclusions.txt"), ScopeFileCallGraph.class.getClassLoader());
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return scope;
    }

    private static void analyse(AnalysisScope scope) {
        ClassHierarchy cha = null;
        try {
            cha = ClassHierarchyFactory.makeWithRoot(scope);
        } catch (ClassHierarchyException ex) {
            ex.printStackTrace();
            return;
        }
        for (IClass c : cha) {
            if (isApplicationClass(c)) {
                Collection<? extends IMethod> declaredMethods = c.getDeclaredMethods();
                AnalysisOptions options = new AnalysisOptions();
                AnalysisCacheImpl analysisCache = new AnalysisCacheImpl(options.getSSAOptions());
                for (IMethod method : declaredMethods) {
                    if (method.isInit() || method.isClinit()) {
                        continue;
                    }
                    System.out.println("Method:" + method.getName());
                    IR ir = analysisCache.getIR(method);
                    if (Objects.isNull(ir)) {
                        System.out.println("IR is null");
                        continue;
                    }

                    analysisParameterName(ir);

                    analysisParameterSpreadTrace(ir);
                }
            }
        }
    }

    /**
     * 分析参数扩散轨迹
     */
    private static void analysisParameterSpreadTrace(IR ir) {
        int numberOfParameters = ir.getNumberOfParameters();
        IMethod method = ir.getMethod();
        List<Integer> parameterVnList = new ArrayList<>();
        int startIndex = 1;
        if (!method.isStatic()) {
            startIndex = 2;
        }
        for (; startIndex <= numberOfParameters; startIndex++) {
            parameterVnList.add(startIndex);
        }

        System.out.println(ir);
        if (VariableNumberManager.isNotEmpty(parameterVnList)) {
            VariableNumberManager manager = new VariableNumberManager(parameterVnList);
            SSAInstruction[] instructions = ir.getInstructions();
            for (int i = 0; i < instructions.length; i++) {
                SSAInstruction instruction = instructions[i];
                if (Objects.isNull(instruction)) {
                    continue;
                }

                // 函数调用 todo

                // 其他赋值操作
                int def = instruction.getDef();
                if (def > -1) {
                    int numberOfUses = instruction.getNumberOfUses();
                    if (numberOfUses > 0) {
                        List<Integer> parentVnList = new ArrayList<>();
                        String vns = "";
                        for (int num = 0; num < numberOfUses; ++num) {
                            int useVn = instruction.getUse(num);
                            parentVnList.add(useVn);
                            vns += useVn + ",";

                        }
                        vns = vns.substring(0, vns.length() - 1);
                        System.out.println("  def:" + def + " use:" + vns);

                        manager.traceMethodParameter(def, parentVnList);
                    }
                }
            }
            manager.print();
        }
    }


    /**
     * 本地参数名称获取规律:
     * <p>
     * <p>
     * 问题I: 获取变量值
     * ir.getLocalNames(i, vn)  i表示在ir之内.
     * 所以获取本地变量只需要: 得到最大的 instruction索引值 + j 即可
     * name = getLocalNames(maxInstructionIndex,vn)
     * <p>
     * 问题II: 获取参数源
     *
     * @param ir
     */
    private static void analysisParameterName(IR ir) {
        System.out.println(ir);
        SSAInstruction[] instructions = ir.getInstructions();

        int numberOfParameters = ir.getNumberOfParameters();
        if (numberOfParameters > 0) {
            StringBuilder args = new StringBuilder("Method[" + ir.getMethod().getName() + "] ArgNames:");
            for (int i = 0; i < numberOfParameters; ++i) {
                args.append("[" + i + "]" + LocalInfoExtractor.getLocalParameterName(ir, (i + 1)) + ",");
            }
            System.out.println(args);
        }

        for (int i = 0; i < instructions.length; i++) {
            SSAInstruction instruction = instructions[i];
            if (Objects.isNull(instruction)) {
                continue;
            }
            System.out.println("instruction index:" + i + " lineNumber:" + LocalInfoExtractor.getLocalLineNumber(ir, instruction));
            int def = instruction.getDef();
            if (def > -1) {
                System.out.println("  def:" + def + " name: " + LocalInfoExtractor.getLocalParameterName(ir, def));
            }
            int numberOfUses = instruction.getNumberOfUses();
            if (numberOfUses > 0) {
                StringBuilder useVn = new StringBuilder("  useVn:");
                for (int num = 0; num < numberOfUses; ++num) {
                    useVn.append(" " + instruction.getUse(num));
                }
                System.out.println(useVn);
            }
        }
    }

    private static boolean isApplicationClass(IClass clz) {
        ClassLoaderReference reference = clz.getClassLoader().getReference();
        return reference.equals(ClassLoaderReference.Application);
    }
}
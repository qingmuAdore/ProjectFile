package top.anemone.walaDemo.analyzer;

import lombok.Data;

import java.util.List;

/**
 * 变量参数传递模型
 *
 * @author z30022129
 * @version v1.0.0
 * @date 2022/3/10
 */
@Data
public class LocalVariable {
    // 变量在IR的vn值
    private int vn;

    // 变量名称
    private String name;

    // 传递扩散的变量
    private List<LocalVariable> children;
}
package top.anemone.walaDemo.analyzer;


import java.util.*;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/3/12
 */
public class VariableNumberManager {
    private Map<Integer, Set<Integer>> localVariableMap = new LinkedHashMap<>();

    private Integer currVn = 0;

    public VariableNumberManager(List<Integer> parameterVNList) {
        for (Integer parameterVN : parameterVNList) {
            Set<Integer> parameterSet = new TreeSet<>();
            parameterSet.add(parameterVN);
            localVariableMap.put(parameterVN, parameterSet);

            if (parameterVN > currVn) {
                currVn = parameterVN;
            }
        }
    }

    /**
     * 追溯参数
     *
     * @param vn
     * @param parentVnList
     */
    public void traceParameter(Integer vn, List<Integer> parentVnList) {
        /**
         * 避免重复操作以及非法操作
         */
        if (check(vn)) {
            currVn = vn;
            Set<Integer> parameterSet = new TreeSet<>();
            for (Integer parentVn : parentVnList) {
                if (isValid(vn, parentVn)) {
                    Set<Integer> set = localVariableMap.get(parentVn);
                    if (isNotEmpty(set)) {
                        parameterSet.addAll(set);
                    }
                }
            }

            if (isNotEmpty(parameterSet)) {
                localVariableMap.put(vn, parameterSet);
            }
        }
    }

    public static boolean isNotEmpty(Collection<Integer> collection) {
        return collection != null && !collection.isEmpty();
    }

    /**
     * vn是单调递增
     */
    private boolean check(Integer vn) {
        return vn > currVn;
    }

    /**
     * 下一级的vn,必然比它上一级大
     */
    private boolean isValid(Integer vn, Integer parentVn) {
        return vn > parentVn;
    }

    public Set<Integer> getParameters(Integer key) {
        return localVariableMap.get(key);
    }

    public void print() {
        Set<Map.Entry<Integer, Set<Integer>>> entries = localVariableMap.entrySet();
        for (Map.Entry<Integer, Set<Integer>> entry : entries) {
            Integer key = entry.getKey();
            Set<Integer> value = entry.getValue();
            display(key, value);
        }
    }

    private void display(Integer key, Set<Integer> value) {
        StringBuilder sb = new StringBuilder();
        sb.append("v" + key);
        sb.append(" params:");
        for (Integer p : value) {
            sb.append("v" + p + " ");
        }
        System.out.println(sb);
    }
}
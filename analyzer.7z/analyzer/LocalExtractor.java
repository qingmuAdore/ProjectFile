package top.anemone.walaDemo.analyzer;

import com.ibm.wala.classLoader.IBytecodeMethod;
import com.ibm.wala.classLoader.IMethod;
import com.ibm.wala.shrikeCT.InvalidClassFileException;
import com.ibm.wala.ssa.IR;
import com.ibm.wala.ssa.SSAInstruction;

import java.util.Objects;

/**
 * @author Lenovo
 * @version v1.0.0
 * @date 2022/3/11
 */
public class LocalExtractor {

    /**
     * 获取参数名称
     */
    public static String getLocalParameterName(IR ir, int vn) {
        if (Objects.isNull(ir)) {
            return "";
        }
        int maxInstructionIndex = ir.getInstructions().length - 1;
        if (maxInstructionIndex < 0 || vn < 0) {
            return "";
        }
        String[] localNames = ir.getLocalNames(maxInstructionIndex, vn);
        if (localNames == null || localNames.length == 0) {
            return "";
        }
        return String.join(",", localNames);
    }

    /**
     * 如何获取 localNumber
     * 不是 vn
     * ?
     */
    public static String getLocalParameterName(IMethod method, int iIndex, int localNumber) {
        try {
            int bytecodeIndex = ((IBytecodeMethod<?>) method).getBytecodeIndex(iIndex);

            return method.getLocalVariableName(bytecodeIndex, localNumber);
        } catch (InvalidClassFileException e) {
            e.printStackTrace();
            return "";
        }
    }

    /**
     * 获取本地代码行号
     *
     * @param ir
     * @param instruction
     * @return
     */
    public static int getLocalLineNumber(IR ir, SSAInstruction instruction) {
        IMethod method = ir.getMethod();
        if (method instanceof IBytecodeMethod) {
            int iIndex = instruction.iIndex();
            if (iIndex == -1) {
                return -1;
            }

            try {
                int bytecodeIndex = ((IBytecodeMethod<?>) method).getBytecodeIndex(iIndex);
                return method.getLineNumber(bytecodeIndex);
            } catch (InvalidClassFileException e) {
                e.printStackTrace();
                return -1;
            }
        }

        return -1;
    }
}